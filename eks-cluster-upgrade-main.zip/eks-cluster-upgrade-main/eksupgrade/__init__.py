"""Initialize the eksupgrade module.

Attributes:
    __version__: The version of the eksupgrade module.

"""

__version__: str = "0.9.0"
