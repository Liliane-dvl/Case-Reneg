"""Handle the main entry logic."""

from .cli import app

app(prog_name="eksupgrade")
